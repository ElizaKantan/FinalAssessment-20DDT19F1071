email = open('emailaddress.txt', 'r')
print(email.read())
email.close()