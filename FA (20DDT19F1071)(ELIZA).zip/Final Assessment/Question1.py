import sys

print('The user should only get 5 tries to enter the password ')
password = "eliza123"

count= 1
loggedin = False

while(not(loggedin)):
        if count > 5:
            print("You are blocked of the system")
            sys.exit()
        loginpass = input("Please enter the password : ")
        if loginpass == password:
            print("You are logged in to the system ")
            loggedin = True
        else:
            count +=1