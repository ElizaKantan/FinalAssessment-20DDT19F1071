from tkinter import *
    
window = Tk()
window.title("GUI Example")
window.config(padx=100,pady=50)
window.geometry("300x300")
stateswap = True

def text():
    global stateswap
    if stateswap:
        textbox["text"] = "I have been changed"
        stateswap = False
    else:
        textbox["text"] = "Changed Text"
        stateswap = True

textbox = Label(text="Changed Text")
btn = Button(text="Change Text",command=text)
textbox.grid(row=3,column=2)
btn.grid(row=2,column=2)

window.mainloop()
