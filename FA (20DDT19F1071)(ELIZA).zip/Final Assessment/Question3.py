with open('emailaddress.txt', mode="a") as myemail:
     myemail.write("dioncools@gmail.com; ")

with open('emailaddress.txt', mode='a') as myemail:
    myemail.write("corbinong@gmail.com; ")

with open('emailaddress.txt', mode='a') as myemail:
    myemail.write("sapokbiki@gmail.com; ")

with open('emailaddress.txt', mode='a') as myemail:
    myemail.write("watsonnyambek@gmail.com; ")