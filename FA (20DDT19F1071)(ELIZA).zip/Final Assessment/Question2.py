class Conversion:

    def __init__(self, kilogram):
        self.kilogram = kilogram

    def kg_to_pound(self):
        return ('{:.3f} pound').format(self.kilogram * 2.20462)


c = Conversion(70)
print(c.kg_to_pound())